"""
Double Entry Life — brand assets generator.
All programmatic: exact gradient hex values, exact fonts, no AI drift.
"""

from PIL import Image, ImageDraw, ImageFont
import math

TEAL_TOP = (32, 171, 191)
TEAL_BOTTOM = (25, 140, 166)
MINT_TOP = (183, 227, 184)
MINT_BOTTOM = (155, 208, 173)
CREAM = (253, 250, 227)

FONT_REGULAR = "/home/claude/fonts/DMSerifDisplay-Regular.ttf"
FONT_ITALIC = "/home/claude/fonts/DMSerifDisplay-Italic.ttf"


def vgradient(w, h, top, bottom):
    grad = Image.new("RGB", (1, h), color=0)
    for y in range(h):
        t = y / (h - 1)
        rgb = tuple(int(top[i] + (bottom[i] - top[i]) * t) for i in range(3))
        grad.putpixel((0, y), rgb)
    return grad.resize((w, h))


def hgradient(w, h, left, right):
    grad = Image.new("RGB", (w, 1), color=0)
    for x in range(w):
        t = x / (w - 1)
        rgb = tuple(int(left[i] + (right[i] - left[i]) * t) for i in range(3))
        grad.putpixel((x, 0), rgb)
    return grad.resize((w, h))


def draw_book(draw, cx, cy, size, color):
    w, h = size, size * 0.7
    top = cy - h / 2
    bottom = cy + h / 2
    left = cx - w / 2
    right = cx + w / 2
    # left page
    draw.polygon([(cx, top + h * 0.08), (left, top), (left, bottom),
                  (cx, bottom - h * 0.08)], fill=color)
    # right page
    draw.polygon([(cx, top + h * 0.08), (right, top), (right, bottom),
                  (cx, bottom - h * 0.08)], fill=color)
    # spine shadow line
    draw.line([(cx, top + h * 0.08), (cx, bottom - h * 0.08)], fill=TEAL_BOTTOM, width=3)


def draw_briefcase(draw, cx, cy, size, color):
    w, h = size, size * 0.72
    left = cx - w / 2
    right = cx + w / 2
    top = cy - h / 2
    bottom = cy + h / 2
    # handle
    handle_w = w * 0.32
    draw.arc([cx - handle_w / 2, top - h * 0.35, cx + handle_w / 2, top + h * 0.15],
              start=180, end=360, fill=color, width=int(size * 0.08))
    # body
    draw.rounded_rectangle([left, top, right, bottom], radius=int(size * 0.08), fill=color)
    # clasp
    clasp_w = w * 0.16
    draw.rectangle([cx - clasp_w / 2, top + h * 0.32, cx + clasp_w / 2, top + h * 0.32 + h * 0.14],
                    fill=TEAL_BOTTOM)
    # divider line
    draw.line([(left, cy), (right, cy)], fill=TEAL_BOTTOM, width=2)


def draw_spark(draw, cx, cy, r_outer, color):
    r_inner = r_outer * 0.32
    pts = []
    for i in range(8):
        angle = math.pi / 4 * i
        r = r_outer if i % 2 == 0 else r_inner
        pts.append((cx + r * math.sin(angle), cy - r * math.cos(angle)))
    draw.polygon(pts, fill=color)


def build_icon_square(out_path):
    W = H = 1024
    canvas = vgradient(W, H, TEAL_TOP, TEAL_BOTTOM)
    right_half = vgradient(W, H, MINT_TOP, MINT_BOTTOM)
    canvas.paste(right_half.crop((W // 2, 0, W, H)), (W // 2, 0))
    draw = ImageDraw.Draw(canvas)

    draw_book(draw, W * 0.30, H * 0.55, 260, CREAM)
    draw_briefcase(draw, W * 0.70, H * 0.55, 220, CREAM)
    draw_spark(draw, W * 0.5, H * 0.30, 70, CREAM)

    canvas.save(out_path, "PNG")


def build_linkedin_banner(out_path):
    W, H = 1584, 396
    canvas = hgradient(W, H, TEAL_TOP, MINT_BOTTOM)
    draw = ImageDraw.Draw(canvas)

    # right third block
    block_cx = W - W // 6 - 40
    icon_y = H * 0.30

    draw_book(draw, block_cx - 90, icon_y, 90, CREAM)
    draw_spark(draw, block_cx, icon_y - 20, 24, CREAM)
    draw_briefcase(draw, block_cx + 90, icon_y, 78, CREAM)

    f_regular = ImageFont.truetype(FONT_REGULAR, 64)
    f_italic = ImageFont.truetype(FONT_ITALIC, 64)
    f_sub = ImageFont.truetype(FONT_ITALIC, 26)

    word_a, word_b = "doubleentry", ".life"
    w_a = draw.textlength(word_a, font=f_regular)
    w_b = draw.textlength(word_b, font=f_italic)
    total_w = w_a + w_b
    x_start = block_cx - total_w / 2
    y_word = H * 0.48

    draw.text((x_start, y_word), word_a, font=f_regular, fill=CREAM)
    draw.text((x_start + w_a, y_word), word_b, font=f_italic, fill=CREAM)

    line_y = y_word + 78
    line_half = total_w / 2 + 20
    draw.line([(block_cx - line_half, line_y), (block_cx + line_half, line_y)], fill=CREAM, width=2)

    sub_text = "Bill's Path to Financial Clarity"
    sub_w = draw.textlength(sub_text, font=f_sub)
    draw.text((block_cx - sub_w / 2, line_y + 14), sub_text, font=f_sub, fill=CREAM)

    canvas.save(out_path, "PNG")


if __name__ == "__main__":
    build_icon_square("/mnt/user-data/outputs/logo_square.png")
    build_linkedin_banner("/mnt/user-data/outputs/linkedin_banner.png")
    print("done")
