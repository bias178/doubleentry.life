from PIL import Image, ImageDraw
import math

TEAL_TOP = (32, 171, 191)
TEAL_BOTTOM = (25, 140, 166)
MINT_TOP = (183, 227, 184)
MINT_BOTTOM = (155, 208, 173)
CREAM = (253, 250, 227)

def vgradient(w, h, top, bottom):
    grad = Image.new("RGB", (1, h), color=0)
    for y in range(h):
        t = y / (h - 1)
        rgb = tuple(int(top[i] + (bottom[i] - top[i]) * t) for i in range(3))
        grad.putpixel((0, y), rgb)
    return grad.resize((w, h))

def draw_spark(draw, cx, cy, r_outer, color):
    r_inner = r_outer * 0.34
    pts = []
    for i in range(8):
        angle = math.pi / 4 * i
        r = r_outer if i % 2 == 0 else r_inner
        pts.append((cx + r * math.sin(angle), cy - r * math.cos(angle)))
    draw.polygon(pts, fill=color)

def build_master(size):
    canvas = vgradient(size, size, TEAL_TOP, TEAL_BOTTOM)
    right_half = vgradient(size, size, MINT_TOP, MINT_BOTTOM)
    canvas.paste(right_half.crop((size // 2, 0, size, size)), (size // 2, 0))
    draw = ImageDraw.Draw(canvas)
    draw_spark(draw, size / 2, size / 2, size * 0.34, CREAM)
    return canvas

master = build_master(512)
master.resize((16, 16), Image.LANCZOS).save("/mnt/user-data/outputs/favicon-16.png")
master.resize((32, 32), Image.LANCZOS).save("/mnt/user-data/outputs/favicon-32.png")
master.resize((180, 180), Image.LANCZOS).save("/mnt/user-data/outputs/favicon-180.png")

# SVG version (vector spark on split gradient), same geometry
def spark_points(cx, cy, r_outer, r_inner):
    pts = []
    for i in range(8):
        angle = math.pi / 4 * i
        r = r_outer if i % 2 == 0 else r_inner
        x = cx + r * math.sin(angle)
        y = cy - r * math.cos(angle)
        pts.append(f"{x:.2f},{y:.2f}")
    return " ".join(pts)

size = 512
pts = spark_points(size/2, size/2, size*0.34, size*0.34*0.34)
svg = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {size} {size}">
  <defs>
    <linearGradient id="teal" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="rgb{TEAL_TOP}" />
      <stop offset="100%" stop-color="rgb{TEAL_BOTTOM}" />
    </linearGradient>
    <linearGradient id="mint" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="rgb{MINT_TOP}" />
      <stop offset="100%" stop-color="rgb{MINT_BOTTOM}" />
    </linearGradient>
  </defs>
  <rect x="0" y="0" width="{size/2}" height="{size}" fill="url(#teal)" />
  <rect x="{size/2}" y="0" width="{size/2}" height="{size}" fill="url(#mint)" />
  <polygon points="{pts}" fill="rgb{CREAM}" />
</svg>'''

with open("/mnt/user-data/outputs/favicon.svg", "w") as f:
    f.write(svg)

print("done")
