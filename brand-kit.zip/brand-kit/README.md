# Double Entry Life — Brand Kit

This folder is the single source of truth for everything that must never drift:
gradient colors, fonts, wordmark styling, logo, favicon, banner.

Nothing in here is AI-generated. Everything is produced by the scripts in
/scripts, so re-running them always gives pixel-identical results.

## Fixed values (never change these without updating everywhere at once)

- Teal gradient: #20abbf (top) to #198ca6 (bottom)
- Mint gradient: #b7e3b8 (top) to #9bd0ad (bottom)
- Cream: #fdfae3
- Wordmark font: DM Serif Display, regular weight, ".life" in italic
- Subtitle: DM Serif Display italic, between two thin cream lines

## Contents

- `/fonts` — DM Serif Display Regular + Italic (pinned copies, do not rely on
  Google Fonts CDN availability for asset generation)
- `/scripts/build_template.py` — generates the per-episode LinkedIn/Substack
  post background: gradient + wordmark + variable subtitle + optional Bill
  cutout composited on top. This is the only piece that changes per post
  (the subtitle text and the Bill artwork).
- `/scripts/build_assets.py` — generates `logo_square.png` (WhatsApp, Gmail,
  Substack profile icon) and `linkedin_banner.png` (1584x396 LinkedIn cover).
- `/scripts/build_favicon.py` — generates `favicon.svg`, `favicon-16.png`,
  `favicon-32.png`, `favicon-180.png` at the exact filenames index.html
  already references.
- `/assets` — current approved output of the three scripts above. These are
  the files actually live on doubleentry.life.

## What is still AI-generated (and therefore the only source of drift)

Bill's illustrated artwork per episode. Everything else on this list is
fixed by code. If a future thumbnail looks off-brand, the problem is almost
certainly in the AI-generated Bill cutout, not in the gradient, font, or
wordmark, since those cannot vary once produced by these scripts.

## How to regenerate

```
pip install pillow --break-system-packages
python3 scripts/build_assets.py
python3 scripts/build_favicon.py
python3 scripts/build_template.py "Subtitle text" output.png bill_cutout.png
```

## Rule going forward

Any change to gradient hex values, fonts, or wordmark layout must happen in
these scripts first, then get re-exported to /assets and re-uploaded to the
site. Never hand-edit a generated PNG, and never let an AI tool regenerate
the logo, favicon, or banner from a text prompt again, since that is exactly
what caused the inconsistency across Ideogram, Gemini, and Leonardo.
